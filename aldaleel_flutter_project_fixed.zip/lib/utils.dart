import 'package:url_launcher/url_launcher.dart';

// رقم تفعيل الاشتراك ورسومه
const String kActivationPhone = '01110001986';
const String kActivationPhoneIntl = '201110001986';
const String kActivationFee = '٦٠';

Future<void> openWhatsApp(String number, String message) async {
  final uri = Uri.parse('https://wa.me/$number?text=${Uri.encodeComponent(message)}');
  if (await canLaunchUrl(uri)) {
    await launchUrl(uri, mode: LaunchMode.externalApplication);
  }
}

Future<void> callNumber(String number) async {
  final uri = Uri.parse('tel:$number');
  if (await canLaunchUrl(uri)) {
    await launchUrl(uri);
  }
}

Future<void> openMap(String query) async {
  final uri = Uri.parse('https://www.google.com/maps/search/?api=1&query=${Uri.encodeComponent(query)}');
  if (await canLaunchUrl(uri)) {
    await launchUrl(uri, mode: LaunchMode.externalApplication);
  }
}
