import 'package:flutter/material.dart';
import '../theme.dart';
import '../utils.dart';
import '../data/mock_data.dart';
import 'widgets.dart';
import 'chat_screen.dart';

class ProScreen extends StatelessWidget {
  final Pro pro;
  const ProScreen({super.key, required this.pro});

  @override
  Widget build(BuildContext context) {
    final c = catById(pro.specialty);
    return Scaffold(
      body: CustomScrollView(slivers: [
        SliverAppBar(
          expandedHeight: 130, pinned: true,
          flexibleSpace: FlexibleSpaceBar(background: Container(
            decoration: const BoxDecoration(gradient: LinearGradient(colors: [kPrimary, Color(0xFF34D399)])))),
        ),
        SliverToBoxAdapter(child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Transform.translate(offset: const Offset(0, -50), child: Row(crossAxisAlignment: CrossAxisAlignment.end, children: [
              ClipRRect(borderRadius: BorderRadius.circular(20),
                child: Image.network(avatar(pro.img), width: 90, height: 90, fit: BoxFit.cover,
                  errorBuilder: (_, __, ___) => Container(width: 90, height: 90, color: Colors.grey.shade200, child: const Icon(Icons.person, size: 40)))),
            ])),
            Transform.translate(offset: const Offset(0, -30), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Row(children: [
                Flexible(child: Text(pro.name, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800))),
                verifiedBadge(pro.verified), const SizedBox(width: 4), tierBadge(pro.premium),
              ]),
              const SizedBox(height: 6),
              Row(children: [
                Container(padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                  decoration: BoxDecoration(color: c.color, borderRadius: BorderRadius.circular(8)),
                  child: Text('${c.icon} ${c.name}', style: const TextStyle(color: Colors.white, fontSize: 12))),
                const SizedBox(width: 8),
                Text('📍 ${pro.gov} · ${pro.city}', style: TextStyle(fontSize: 12, color: Colors.grey.shade600)),
              ]),
              const SizedBox(height: 16),
              Row(children: [
                _stat('${pro.rating}', 'التقييم'),
                _stat('${pro.exp}', 'سنة خبرة'),
                _stat('${pro.jobsDone}', 'عمل منجز'),
              ]),
              const SizedBox(height: 16),
              const Text('نبذة', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
              const SizedBox(height: 4),
              Text(pro.about, style: TextStyle(color: Colors.grey.shade700, height: 1.6)),
              const SizedBox(height: 16),
              const Text('معرض الأعمال', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
              const SizedBox(height: 8),
              SizedBox(height: 110, child: ListView(scrollDirection: Axis.horizontal,
                children: List.generate(4, (i) => Padding(padding: const EdgeInsets.only(left: 8),
                  child: ClipRRect(borderRadius: BorderRadius.circular(12),
                    child: Image.network('https://picsum.photos/seed/${pro.id}$i/200/200', width: 110, height: 110, fit: BoxFit.cover,
                      errorBuilder: (_, __, ___) => Container(width: 110, height: 110, color: Colors.grey.shade200))))))),
              const SizedBox(height: 16),
              const Text('التقييمات', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
              const SizedBox(height: 8),
              _review('هاني محمود', 5, 'شغل ممتاز ومواعيد محترمة، أنصح بالتعامل معاه.'),
              _review('وليد سمير', 5, 'أمانة وإتقان، حل المشكلة بسرعة وبسعر مناسب.'),
            ])),
          ]),
        )),
      ]),
      bottomNavigationBar: SafeArea(child: Padding(
        padding: const EdgeInsets.all(12),
        child: Row(children: [
          Expanded(child: ElevatedButton.icon(
            icon: const Icon(Icons.phone, size: 18), label: const Text('اتصال'),
            onPressed: () => callNumber(pro.phone))),
          const SizedBox(width: 8),
          Expanded(child: ElevatedButton.icon(
            style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFF22C55E)),
            icon: const Text('💬'), label: const Text('واتساب'),
            onPressed: () => openWhatsApp(pro.whatsapp, 'مرحباً ${pro.name}، وجدت ملفك على تطبيق الدليل الشامل'))),
          const SizedBox(width: 8),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: Colors.grey.shade200, foregroundColor: Colors.black87, padding: const EdgeInsets.all(14)),
            onPressed: () {
              if (!Store.I.isMember) { snack(context, '🔒 سجّل عضوية لبدء المحادثة'); return; }
              Navigator.push(context, MaterialPageRoute(builder: (_) => ChatScreen(pro: pro)));
            },
            child: const Icon(Icons.chat_bubble_outline)),
        ]),
      )),
    );
  }

  Widget _stat(String n, String l) => Expanded(child: Container(
    margin: const EdgeInsets.symmetric(horizontal: 3),
    padding: const EdgeInsets.symmetric(vertical: 12),
    decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(12), border: Border.all(color: Colors.grey.shade200)),
    child: Column(children: [
      Text(n, style: const TextStyle(color: kPrimary, fontWeight: FontWeight.w800, fontSize: 18)),
      Text(l, style: TextStyle(fontSize: 10, color: Colors.grey.shade500)),
    ]),
  ));

  Widget _review(String name, int r, String text) => Container(
    margin: const EdgeInsets.only(bottom: 8), padding: const EdgeInsets.all(12),
    decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(12), border: Border.all(color: Colors.grey.shade200)),
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Row(children: [Text(name, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13)), const Spacer(), stars(r.toDouble())]),
      const SizedBox(height: 6),
      Text(text, style: TextStyle(fontSize: 12, color: Colors.grey.shade700)),
    ]),
  );
}
