import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import '../theme.dart';
import '../utils.dart';
import '../data/mock_data.dart';
import 'widgets.dart';

class WorksTab extends StatelessWidget {
  const WorksTab({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('أعمال الأعضاء')),
      body: AnimatedBuilder(
        animation: Store.I,
        builder: (context, _) => ListView(padding: const EdgeInsets.all(12), children: [
          OutlinedButton.icon(
            style: OutlinedButton.styleFrom(
              foregroundColor: kPrimary, padding: const EdgeInsets.symmetric(vertical: 14),
              side: const BorderSide(color: kPrimary, style: BorderStyle.solid),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
            ),
            icon: const Icon(Icons.add_a_photo_outlined),
            label: const Text('انشر عمل جديد', style: TextStyle(fontWeight: FontWeight.bold)),
            onPressed: () {
              if (!Store.I.isMember) { snack(context, '🔒 سجّل عضوية لنشر أعمالك'); return; }
              Navigator.push(context, MaterialPageRoute(builder: (_) => const PublishWorkScreen()));
            },
          ),
          const SizedBox(height: 12),
          ...Store.I.works.map((w) => _workCard(context, w)),
        ]),
      ),
    );
  }

  Widget _workCard(BuildContext context, Work w) {
    final p = w.proId == 0 ? null : proById(w.proId);
    final c = catById(w.cat);
    final name = p?.name ?? 'أنت (عضو الدليل)';
    final img = p?.img ?? 50;
    final whats = p?.whatsapp ?? kActivationPhoneIntl;
    Widget image;
    if (w.imagePath != null) {
      image = Image.file(File(w.imagePath!), height: 220, width: double.infinity, fit: BoxFit.cover);
    } else {
      image = Image.network('https://picsum.photos/seed/${w.seed}/400/300', height: 220, width: double.infinity, fit: BoxFit.cover,
        errorBuilder: (_, __, ___) => Container(height: 220, color: Colors.grey.shade200));
    }
    return Card(
      margin: const EdgeInsets.only(bottom: 14),
      clipBehavior: Clip.antiAlias,
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Padding(padding: const EdgeInsets.all(10), child: Row(children: [
          ClipRRect(borderRadius: BorderRadius.circular(20),
            child: Image.network(avatar(img), width: 40, height: 40, fit: BoxFit.cover,
              errorBuilder: (_, __, ___) => const CircleAvatar(child: Icon(Icons.person)))),
          const SizedBox(width: 8),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [Flexible(child: Text(name, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13))), verifiedBadge(p?.verified ?? true)]),
            Text(w.time, style: TextStyle(fontSize: 10, color: Colors.grey.shade500)),
          ])),
          Container(padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
            decoration: BoxDecoration(color: c.color, borderRadius: BorderRadius.circular(8)),
            child: Text(c.name, style: const TextStyle(color: Colors.white, fontSize: 10))),
        ])),
        image,
        Padding(padding: const EdgeInsets.all(12), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(w.title, style: const TextStyle(fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
            Text('❤️ ${w.likes}', style: const TextStyle(color: Colors.red, fontWeight: FontWeight.bold, fontSize: 13)),
            ElevatedButton(
              style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFF22C55E), padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6)),
              onPressed: () => openWhatsApp(whats, 'مرحباً، أعجبني عملك: ${w.title}'),
              child: const Text('💬 تواصل', style: TextStyle(fontSize: 12)),
            ),
          ]),
        ])),
      ]),
    );
  }
}

class PublishWorkScreen extends StatefulWidget {
  const PublishWorkScreen({super.key});
  @override
  State<PublishWorkScreen> createState() => _PublishWorkScreenState();
}

class _PublishWorkScreenState extends State<PublishWorkScreen> {
  final _title = TextEditingController();
  String cat = 'plumbing';
  String? _imagePath;

  Future<void> _pick() async {
    final picker = ImagePicker();
    final XFile? file = await picker.pickImage(source: ImageSource.gallery, maxWidth: 1200, imageQuality: 80);
    if (file != null) setState(() => _imagePath = file.path);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('نشر عمل جديد')),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        GestureDetector(
          onTap: _pick,
          child: Container(
            height: 200,
            decoration: BoxDecoration(
              color: Colors.grey.shade100,
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: Colors.grey.shade300, width: 2),
              image: _imagePath != null ? DecorationImage(image: FileImage(File(_imagePath!)), fit: BoxFit.cover) : null,
            ),
            child: _imagePath == null
              ? Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                  const Icon(Icons.camera_alt_outlined, size: 40, color: Colors.grey),
                  const SizedBox(height: 8),
                  Text('اضغط لاختيار صورة العمل من موبايلك', style: TextStyle(color: Colors.grey.shade500, fontSize: 12)),
                ])
              : null,
          ),
        ),
        const SizedBox(height: 16),
        TextField(controller: _title, decoration: InputDecoration(
          labelText: 'عنوان العمل', filled: true, fillColor: Colors.white,
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)))),
        const SizedBox(height: 12),
        DropdownButtonFormField<String>(
          value: cat,
          decoration: InputDecoration(labelText: 'القسم', filled: true, fillColor: Colors.white,
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(12))),
          items: kCategories.map((c) => DropdownMenuItem(value: c.id, child: Text(c.name))).toList(),
          onChanged: (v) => setState(() => cat = v!),
        ),
        const SizedBox(height: 24),
        ElevatedButton(
          onPressed: () {
            Store.I.addWork(_title.text.trim().isEmpty ? 'عمل جديد' : _title.text.trim(), cat, _imagePath);
            snack(context, '✅ تم نشر عملك بنجاح');
            Navigator.pop(context);
          },
          child: const Text('نشر العمل 📤'),
        ),
      ]),
    );
  }
}
