import 'package:flutter/material.dart';
import '../theme.dart';
import 'home_tab.dart';
import 'directory_tab.dart';
import 'works_tab.dart';
import 'menu_tab.dart';

class HomeShell extends StatefulWidget {
  const HomeShell({super.key});
  @override
  State<HomeShell> createState() => _HomeShellState();
}

class _HomeShellState extends State<HomeShell> {
  int idx = 0;
  final tabs = const [HomeTab(), DirectoryTab(), WorksTab(), RequestsTab(), MenuTab()];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: tabs[idx],
      bottomNavigationBar: NavigationBar(
        selectedIndex: idx,
        onDestinationSelected: (i) => setState(() => idx = i),
        indicatorColor: kPrimary.withOpacity(0.15),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'الرئيسية'),
          NavigationDestination(icon: Icon(Icons.list_alt_outlined), selectedIcon: Icon(Icons.list_alt), label: 'الدليل'),
          NavigationDestination(icon: Icon(Icons.photo_library_outlined), selectedIcon: Icon(Icons.photo_library), label: 'الأعمال'),
          NavigationDestination(icon: Icon(Icons.assignment_outlined), selectedIcon: Icon(Icons.assignment), label: 'الطلبات'),
          NavigationDestination(icon: Icon(Icons.person_outline), selectedIcon: Icon(Icons.person), label: 'حسابي'),
        ],
      ),
    );
  }
}

// شاشة طلبات بسيطة
class RequestsTab extends StatelessWidget {
  const RequestsTab({super.key});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('طلبات الخدمة')),
      body: const Center(child: Padding(
        padding: EdgeInsets.all(32),
        child: Text('قسم طلبات الخدمة\nيتيح للعملاء إنشاء طلب وللحرفيين تقديم العروض.',
          textAlign: TextAlign.center, style: TextStyle(color: Colors.grey)),
      )),
    );
  }
}
