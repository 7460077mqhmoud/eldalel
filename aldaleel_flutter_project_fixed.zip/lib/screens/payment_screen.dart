import 'package:flutter/material.dart';
import '../theme.dart';
import '../utils.dart';
import '../data/mock_data.dart';
import 'home_shell.dart';
import 'widgets.dart';

class PaymentScreen extends StatelessWidget {
  const PaymentScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
            const Text('👑', style: TextStyle(fontSize: 64)),
            const SizedBox(height: 12),
            const Text('تفعيل العضوية', style: TextStyle(fontSize: 24, fontWeight: FontWeight.w800)),
            const SizedBox(height: 12),
            Text('للاستمتاع بكل المزايا ونشر أعمالك وتلقي الطلبات من العملاء، يتطلب تفعيل حسابك.',
              textAlign: TextAlign.center, style: TextStyle(color: Colors.grey.shade600, height: 1.6)),
            const SizedBox(height: 28),
            Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: const Color(0xFFFFFBEB),
                border: Border.all(color: kAmber, width: 2),
                borderRadius: BorderRadius.circular(24),
              ),
              child: Column(children: [
                Text('رسوم الاشتراك', style: TextStyle(fontWeight: FontWeight.bold, color: Colors.grey.shade700)),
                const SizedBox(height: 6),
                Text('$kActivationFee جنيه', style: const TextStyle(fontSize: 34, fontWeight: FontWeight.w800, color: Color(0xFFD97706))),
                const Divider(height: 24),
                const Text('حوّل المبلغ عبر فودافون كاش أو إنستا باي على الرقم:', textAlign: TextAlign.center),
                const SizedBox(height: 10),
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.symmetric(vertical: 12),
                  decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(12), border: Border.all(color: kAmber.withOpacity(0.4))),
                  child: const Text(kActivationPhone, textAlign: TextAlign.center,
                    style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold, color: kPrimary, letterSpacing: 2)),
                ),
              ]),
            ),
            const SizedBox(height: 28),
            SizedBox(width: double.infinity, child: ElevatedButton.icon(
              style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFF22C55E)),
              icon: const Text('💬', style: TextStyle(fontSize: 18)),
              label: const Text('تواصل عبر واتساب للتفعيل'),
              onPressed: () => openWhatsApp(kActivationPhoneIntl,
                'السلام عليكم، أرغب في تفعيل عضويتي في تطبيق الدليل الشامل ودفع رسوم الاشتراك $kActivationFee جنيه'),
            )),
            const SizedBox(height: 12),
            SizedBox(width: double.infinity, child: ElevatedButton(
              onPressed: () {
                Store.I.setRole('user');
                snack(context, '✅ تم إرسال طلبك للإدارة.. قيد المراجعة');
                Navigator.pushAndRemoveUntil(context, MaterialPageRoute(builder: (_) => const HomeShell()), (r) => false);
              },
              child: const Text('لقد قمت بالتحويل ✔️'),
            )),
            TextButton(
              onPressed: () {
                Store.I.setRole('guest');
                Navigator.pushAndRemoveUntil(context, MaterialPageRoute(builder: (_) => const HomeShell()), (r) => false);
              },
              child: const Text('الدخول كزائر مؤقتاً'),
            ),
          ]),
        ),
      ),
    );
  }
}
