import 'package:flutter/material.dart';
import '../data/mock_data.dart';
import '../theme.dart';

// نجمات التقييم
Widget stars(double r, {double size = 13}) {
  final full = r.round();
  return Row(mainAxisSize: MainAxisSize.min, children: List.generate(5, (i) =>
    Icon(i < full ? Icons.star : Icons.star_border, size: size, color: kAmber)));
}

Widget verifiedBadge(bool v) {
  if (!v) return const SizedBox.shrink();
  return Container(
    margin: const EdgeInsets.symmetric(horizontal: 3),
    padding: const EdgeInsets.all(2),
    decoration: const BoxDecoration(color: Color(0xFF3B82F6), shape: BoxShape.circle),
    child: const Icon(Icons.check, size: 10, color: Colors.white),
  );
}

Widget tierBadge(bool premium) {
  if (!premium) return const SizedBox.shrink();
  return Container(
    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
    decoration: BoxDecoration(
      gradient: const LinearGradient(colors: [Color(0xFFFBBF24), Color(0xFFF59E0B)]),
      borderRadius: BorderRadius.circular(20),
    ),
    child: const Text('عضوية الدليل', style: TextStyle(fontSize: 10, fontWeight: FontWeight.bold, color: Color(0xFF78350F))),
  );
}

void snack(BuildContext c, String msg) {
  ScaffoldMessenger.of(c).showSnackBar(SnackBar(
    content: Text(msg, textAlign: TextAlign.center),
    behavior: SnackBarBehavior.floating,
    backgroundColor: const Color(0xFF1E293B),
    duration: const Duration(milliseconds: 1600),
  ));
}

class ProCard extends StatelessWidget {
  final Pro p;
  final VoidCallback onTap;
  const ProCard({super.key, required this.p, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: Store.I,
      builder: (context, _) {
        final fav = Store.I.favorites.contains(p.id);
        final c = catById(p.specialty);
        return InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(18),
          child: Card(
            child: Padding(
              padding: const EdgeInsets.all(10),
              child: Row(children: [
                ClipRRect(
                  borderRadius: BorderRadius.circular(12),
                  child: Image.network(avatar(p.img), width: 60, height: 60, fit: BoxFit.cover,
                    errorBuilder: (_, __, ___) => Container(width: 60, height: 60, color: Colors.grey.shade200, child: const Icon(Icons.person))),
                ),
                const SizedBox(width: 10),
                Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Row(children: [
                    Flexible(child: Text(p.name, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15), overflow: TextOverflow.ellipsis)),
                    verifiedBadge(p.verified),
                  ]),
                  const SizedBox(height: 3),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                    decoration: BoxDecoration(color: c.color, borderRadius: BorderRadius.circular(6)),
                    child: Text('${c.icon} ${c.name}', style: const TextStyle(color: Colors.white, fontSize: 10)),
                  ),
                  const SizedBox(height: 4),
                  Row(children: [stars(p.rating), const SizedBox(width: 4), Text('${p.rating} (${p.reviews})', style: TextStyle(fontSize: 11, color: Colors.grey.shade500))]),
                  const SizedBox(height: 2),
                  Text('📍 ${p.gov} · ${p.city} · ${p.exp} سنة', style: TextStyle(fontSize: 11, color: Colors.grey.shade500)),
                ])),
                IconButton(
                  onPressed: () => Store.I.toggleFav(p.id),
                  icon: Icon(fav ? Icons.favorite : Icons.favorite_border, color: fav ? Colors.red : Colors.grey.shade400),
                ),
              ]),
            ),
          ),
        );
      },
    );
  }
}
