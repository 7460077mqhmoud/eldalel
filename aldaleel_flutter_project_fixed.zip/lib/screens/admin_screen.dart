import 'package:flutter/material.dart';
import '../theme.dart';
import '../utils.dart';
import '../data/mock_data.dart';

// طلب تسجيل بانتظار الموافقة
class PendingUser {
  final String name, gov, city, phone;
  final int exp, img;
  final bool paid;
  const PendingUser(this.name, this.gov, this.city, this.phone, this.exp, this.img, this.paid);
}

const _pending = [
  PendingUser('طارق محمد علي', 'أسيوط', 'الفتح', '+201015556661', 5, 40, true),
  PendingUser('شركة المهندسون للمقاولات', 'الإسكندرية', 'المنتزه', '+201015556662', 14, 52, false),
  PendingUser('م. هبة سمير', 'المنيا', 'ملوي', '+201015556663', 7, 47, true),
  PendingUser('معرض الأصالة للرخام', 'الغربية', 'طنطا', '+201015556664', 9, 36, false),
];

class AdminLoginScreen extends StatefulWidget {
  const AdminLoginScreen({super.key});
  @override
  State<AdminLoginScreen> createState() => _AdminLoginScreenState();
}

class _AdminLoginScreenState extends State<AdminLoginScreen> {
  final _email = TextEditingController(text: 'admin@aldaleel.com');
  final _pass = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0F172A),
      appBar: AppBar(backgroundColor: Colors.transparent, foregroundColor: Colors.white, elevation: 0),
      body: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
          const Text('🛡️', style: TextStyle(fontSize: 56)),
          const SizedBox(height: 12),
          const Text('لوحة الإدارة', style: TextStyle(color: Colors.white, fontSize: 24, fontWeight: FontWeight.w800)),
          const SizedBox(height: 24),
          TextField(controller: _email, style: const TextStyle(color: Colors.white), textAlign: TextAlign.center,
            decoration: _dec('البريد الإلكتروني')),
          const SizedBox(height: 12),
          TextField(controller: _pass, obscureText: true, style: const TextStyle(color: Colors.white), textAlign: TextAlign.center,
            decoration: _dec('كلمة المرور (123456)')),
          const SizedBox(height: 20),
          SizedBox(width: double.infinity, child: ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFFE11D48)),
            onPressed: () {
              if (_email.text == 'admin@aldaleel.com' && _pass.text == '123456') {
                Store.I.setRole('admin');
                Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => const AdminDashboard()));
              } else {
                ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('❌ بيانات غير صحيحة')));
              }
            },
            child: const Text('دخول كأدمن'),
          )),
        ]),
      ),
    );
  }

  InputDecoration _dec(String h) => InputDecoration(
    hintText: h, hintStyle: const TextStyle(color: Colors.white38),
    filled: true, fillColor: const Color(0xFF1E293B),
    border: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: BorderSide.none),
  );
}

class AdminDashboard extends StatefulWidget {
  const AdminDashboard({super.key});
  @override
  State<AdminDashboard> createState() => _AdminDashboardState();
}

class _AdminDashboardState extends State<AdminDashboard> {
  final Set<int> _handled = {};

  @override
  Widget build(BuildContext context) {
    final visible = [for (int i = 0; i < _pending.length; i++) if (!_handled.contains(i)) i];
    return Scaffold(
      appBar: AppBar(
        backgroundColor: const Color(0xFF0F172A),
        title: const Text('🛡️ الإدارة'),
        actions: [TextButton(onPressed: () => Navigator.popUntil(context, (r) => r.isFirst), child: const Text('خروج', style: TextStyle(color: Colors.white70)))],
      ),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        Row(children: [
          _kpi('طلبات التفعيل', '${visible.length}', Colors.red),
          const SizedBox(width: 12),
          _kpi('إجمالي المشتركين', '١٢٤٥٠', kPrimary),
        ]),
        const SizedBox(height: 16),
        const Text('المستخدمون في انتظار الموافقة', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
        const SizedBox(height: 12),
        ...visible.map((i) => _pendingCard(i, _pending[i])),
      ]),
    );
  }

  Widget _kpi(String label, String n, Color c) => Expanded(child: Card(child: Padding(
    padding: const EdgeInsets.all(14),
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text(label, style: TextStyle(fontSize: 12, color: Colors.grey.shade600, fontWeight: FontWeight.bold)),
      const SizedBox(height: 4),
      Text(n, style: TextStyle(fontSize: 26, fontWeight: FontWeight.w800, color: c)),
    ]),
  )));

  Widget _pendingCard(int i, PendingUser u) => Card(
    margin: const EdgeInsets.only(bottom: 12),
    child: Padding(padding: const EdgeInsets.all(12), child: Column(children: [
      Row(children: [
        ClipRRect(borderRadius: BorderRadius.circular(12),
          child: Image.network(avatar(u.img), width: 48, height: 48, fit: BoxFit.cover,
            errorBuilder: (_, __, ___) => const CircleAvatar(child: Icon(Icons.person)))),
        const SizedBox(width: 10),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(u.name, style: const TextStyle(fontWeight: FontWeight.bold)),
          Text('${u.gov} · ${u.city} · ${u.exp} سنة', style: TextStyle(fontSize: 11, color: Colors.grey.shade600)),
          Text(u.phone, style: const TextStyle(fontSize: 11, color: kPrimary)),
        ])),
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
          decoration: BoxDecoration(color: u.paid ? kPrimary : kAmber, borderRadius: BorderRadius.circular(20)),
          child: Text(u.paid ? 'دفع $kActivationFee ج' : 'بانتظار الدفع', style: const TextStyle(color: Colors.white, fontSize: 10, fontWeight: FontWeight.bold)),
        ),
      ]),
      const Divider(),
      Row(children: [
        Expanded(child: ElevatedButton(
          onPressed: () { setState(() => _handled.add(i)); ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('تم التفعيل ✅'))); },
          child: const Text('قبول وتفعيل', style: TextStyle(fontSize: 13)),
        )),
        const SizedBox(width: 8),
        Expanded(child: ElevatedButton(
          style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFFFEE2E2), foregroundColor: const Color(0xFFB91C1C)),
          onPressed: () { setState(() => _handled.add(i)); ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('تم الرفض ❌'))); },
          child: const Text('رفض', style: TextStyle(fontSize: 13)),
        )),
      ]),
    ])),
  );
}
