import 'package:flutter/material.dart';
import '../data/mock_data.dart';
import 'payment_screen.dart';

class RegisterScreen extends StatefulWidget {
  const RegisterScreen({super.key});
  @override
  State<RegisterScreen> createState() => _RegisterScreenState();
}

class _RegisterScreenState extends State<RegisterScreen> {
  final _form = GlobalKey<FormState>();
  String role = 'craftsman';
  String cat = 'plumbing';
  String gov = kGovernorates.first;

  InputDecoration _dec(String label) => InputDecoration(
    labelText: label,
    filled: true, fillColor: Colors.white,
    border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide(color: Colors.grey.shade300)),
    contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 12),
  );

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('عضوية جديدة')),
      body: Form(
        key: _form,
        child: ListView(padding: const EdgeInsets.all(16), children: [
          TextFormField(decoration: _dec('الاسم أو اسم الشركة'), validator: _req),
          const SizedBox(height: 12),
          Row(children: [
            Expanded(child: DropdownButtonFormField<String>(
              value: role, decoration: _dec('نوع العضوية'),
              items: const [
                DropdownMenuItem(value: 'craftsman', child: Text('حرفي / فني')),
                DropdownMenuItem(value: 'engineer', child: Text('مهندس')),
                DropdownMenuItem(value: 'company', child: Text('شركة مقاولات')),
                DropdownMenuItem(value: 'supplier', child: Text('مورد')),
              ],
              onChanged: (v) => setState(() => role = v!),
            )),
            const SizedBox(width: 10),
            Expanded(child: DropdownButtonFormField<String>(
              value: cat, decoration: _dec('التخصص'),
              items: kCategories.map((c) => DropdownMenuItem(value: c.id, child: Text(c.name))).toList(),
              onChanged: (v) => setState(() => cat = v!),
            )),
          ]),
          const SizedBox(height: 12),
          DropdownButtonFormField<String>(
            value: gov, decoration: _dec('المحافظة'), isExpanded: true,
            items: kGovernorates.map((g) => DropdownMenuItem(value: g, child: Text(g))).toList(),
            onChanged: (v) => setState(() => gov = v!),
          ),
          const SizedBox(height: 12),
          TextFormField(decoration: _dec('المدينة'), validator: _req),
          const SizedBox(height: 12),
          TextFormField(decoration: _dec('العنوان التفصيلي'), validator: _req),
          const SizedBox(height: 12),
          Row(children: [
            Expanded(child: TextFormField(decoration: _dec('رقم الموبايل'), keyboardType: TextInputType.phone, validator: _req)),
            const SizedBox(width: 10),
            Expanded(child: TextFormField(decoration: _dec('سنوات الخبرة'), keyboardType: TextInputType.number)),
          ]),
          const SizedBox(height: 24),
          ElevatedButton(
            onPressed: () {
              if (_form.currentState!.validate()) {
                Navigator.push(context, MaterialPageRoute(builder: (_) => const PaymentScreen()));
              }
            },
            child: const Text('التالي ←'),
          ),
        ]),
      ),
    );
  }

  String? _req(String? v) => (v == null || v.trim().isEmpty) ? 'مطلوب' : null;
}
