import 'package:flutter/material.dart';
import '../theme.dart';
import '../utils.dart';
import '../data/mock_data.dart';

class ChatScreen extends StatefulWidget {
  final Pro pro;
  const ChatScreen({super.key, required this.pro});
  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  final _ctrl = TextEditingController();
  final _scroll = ScrollController();

  void _send() {
    final t = _ctrl.text.trim();
    if (t.isEmpty) return;
    Store.I.sendMsg(widget.pro.id, t);
    _ctrl.clear();
    _scrollDown();
  }

  void _scrollDown() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scroll.hasClients) _scroll.animateTo(_scroll.position.maxScrollExtent, duration: const Duration(milliseconds: 250), curve: Curves.easeOut);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        titleSpacing: 0,
        title: Row(children: [
          ClipRRect(borderRadius: BorderRadius.circular(20),
            child: Image.network(avatar(widget.pro.img), width: 36, height: 36, fit: BoxFit.cover,
              errorBuilder: (_, __, ___) => const CircleAvatar(child: Icon(Icons.person)))),
          const SizedBox(width: 8),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisAlignment: MainAxisAlignment.center, children: [
            Text(widget.pro.name, style: const TextStyle(fontSize: 15, fontWeight: FontWeight.bold)),
            const Text('متصل الآن', style: TextStyle(fontSize: 10, color: Colors.white70)),
          ])),
        ]),
        actions: [
          IconButton(icon: const Icon(Icons.phone), onPressed: () => callNumber(widget.pro.phone)),
          IconButton(icon: const Text('💬'), onPressed: () => openWhatsApp(widget.pro.whatsapp, '')),
        ],
      ),
      body: Column(children: [
        Expanded(child: AnimatedBuilder(
          animation: Store.I,
          builder: (context, _) {
            final msgs = Store.I.chatFor(widget.pro.id);
            _scrollDown();
            return Container(
              color: const Color(0xFFE8E4DC),
              child: ListView.builder(
                controller: _scroll, padding: const EdgeInsets.all(12),
                itemCount: msgs.length,
                itemBuilder: (context, i) {
                  final m = msgs[i];
                  return Align(
                    alignment: m.mine ? Alignment.centerLeft : Alignment.centerRight,
                    child: Container(
                      margin: const EdgeInsets.symmetric(vertical: 3),
                      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                      constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * 0.75),
                      decoration: BoxDecoration(
                        color: m.mine ? kPrimary : Colors.white,
                        borderRadius: BorderRadius.only(
                          topLeft: const Radius.circular(16), topRight: const Radius.circular(16),
                          bottomLeft: Radius.circular(m.mine ? 4 : 16), bottomRight: Radius.circular(m.mine ? 16 : 4),
                        ),
                      ),
                      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        Text(m.text, style: TextStyle(color: m.mine ? Colors.white : Colors.black87, height: 1.4)),
                        const SizedBox(height: 2),
                        Text('${m.time}${m.mine ? ' ✓✓' : ''}', style: TextStyle(fontSize: 9, color: m.mine ? Colors.white70 : Colors.grey)),
                      ]),
                    ),
                  );
                },
              ),
            );
          },
        )),
        SafeArea(child: Container(
          color: Colors.white, padding: const EdgeInsets.all(8),
          child: Row(children: [
            Expanded(child: TextField(
              controller: _ctrl,
              decoration: InputDecoration(hintText: 'اكتب رسالة...', filled: true, fillColor: const Color(0xFFF1F5F9),
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(24), borderSide: BorderSide.none),
                contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10)),
              onSubmitted: (_) => _send(),
            )),
            const SizedBox(width: 8),
            FloatingActionButton.small(onPressed: _send, backgroundColor: kPrimary, child: const Icon(Icons.send, color: Colors.white, size: 18)),
          ]),
        )),
      ]),
    );
  }
}
