import 'package:flutter/material.dart';
import '../theme.dart';
import '../data/mock_data.dart';
import 'widgets.dart';
import 'pro_screen.dart';

class DirectoryTab extends StatefulWidget {
  const DirectoryTab({super.key});
  @override
  State<DirectoryTab> createState() => _DirectoryTabState();
}

class _DirectoryTabState extends State<DirectoryTab> {
  String? cat;
  String? gov;

  @override
  Widget build(BuildContext context) {
    var list = kPros.where((p) => (cat == null || p.specialty == cat) && (gov == null || p.gov == gov)).toList();
    list.sort((a, b) {
      final t = (b.premium ? 1 : 0) - (a.premium ? 1 : 0);
      return t != 0 ? t : b.rating.compareTo(a.rating);
    });
    return Scaffold(
      appBar: AppBar(title: const Text('دليل الحرفيين')),
      body: Column(children: [
        SizedBox(height: 52, child: ListView(
          scrollDirection: Axis.horizontal, padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
          children: [
            _chip('الكل', cat == null, () => setState(() => cat = null)),
            ...kCategories.map((c) => _chip('${c.icon} ${c.name}', cat == c.id, () => setState(() => cat = c.id))),
          ],
        )),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 12),
          child: DropdownButtonFormField<String>(
            value: gov, isExpanded: true,
            decoration: InputDecoration(filled: true, fillColor: Colors.white, hintText: 'كل المحافظات',
              border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)), contentPadding: const EdgeInsets.symmetric(horizontal: 12)),
            items: [const DropdownMenuItem(value: null, child: Text('كل المحافظات')),
              ...kGovernorates.map((g) => DropdownMenuItem(value: g, child: Text(g)))],
            onChanged: (v) => setState(() => gov = v),
          ),
        ),
        Expanded(child: ListView(padding: const EdgeInsets.all(12),
          children: list.map((p) => Padding(padding: const EdgeInsets.only(bottom: 10),
            child: ProCard(p: p, onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => ProScreen(pro: p)))))).toList())),
      ]),
    );
  }

  Widget _chip(String label, bool sel, VoidCallback onTap) => Padding(
    padding: const EdgeInsets.only(left: 8),
    child: ChoiceChip(label: Text(label), selected: sel, onSelected: (_) => onTap(),
      selectedColor: kPrimary, labelStyle: TextStyle(color: sel ? Colors.white : Colors.black87, fontSize: 12)),
  );
}
