import 'package:flutter/material.dart';
import '../theme.dart';
import '../utils.dart';
import '../data/mock_data.dart';
import 'widgets.dart';
import 'pro_screen.dart';
import 'landing_screen.dart';

class MenuTab extends StatelessWidget {
  const MenuTab({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('حسابي')),
      body: AnimatedBuilder(
        animation: Store.I,
        builder: (context, _) {
          final favs = kPros.where((p) => Store.I.favorites.contains(p.id)).toList();
          return ListView(padding: const EdgeInsets.all(16), children: [
            if (Store.I.isMember)
              Card(child: ListTile(
                leading: const CircleAvatar(backgroundColor: kPrimary, child: Icon(Icons.person, color: Colors.white)),
                title: const Text('زيزو محمد', style: TextStyle(fontWeight: FontWeight.bold)),
                subtitle: const Text('عضوية الدليل ✓'),
              ))
            else
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(gradient: const LinearGradient(colors: [kPrimary, Color(0xFF14B8A6)]), borderRadius: BorderRadius.circular(16)),
                child: Column(children: [
                  const Text('أنت تتصفح كزائر', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 8),
                  SizedBox(width: double.infinity, child: ElevatedButton(
                    style: ElevatedButton.styleFrom(backgroundColor: Colors.white, foregroundColor: kPrimary),
                    onPressed: () => Navigator.pushAndRemoveUntil(context, MaterialPageRoute(builder: (_) => const LandingScreen()), (r) => false),
                    child: Text('سجل الآن بـ $kActivationFee ج فقط'),
                  )),
                ]),
              ),
            const SizedBox(height: 16),
            Text('المفضلة (${favs.length}) ❤️', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
            const SizedBox(height: 8),
            if (favs.isEmpty)
              const Card(child: Padding(padding: EdgeInsets.all(16), child: Center(child: Text('لا توجد عناصر محفوظة بعد', style: TextStyle(color: Colors.grey)))))
            else
              ...favs.map((p) => Padding(padding: const EdgeInsets.only(bottom: 8),
                child: ProCard(p: p, onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => ProScreen(pro: p)))))),
            const SizedBox(height: 8),
            Card(child: Column(children: [
              _tile(Icons.work_outline, 'الوظائف', () => snack(context, 'قسم الوظائف')),
              _tile(Icons.info_outline, 'من نحن', () => _page(context, 'من نحن',
                'الدليل الشامل هو أكبر منصة رقمية في مصر تجمع الحرفيين والمهندسين والموردين وشركات المقاولات لتسهيل الوصول إليهم وطلب خدماتهم بضغطة زر.')),
              _tile(Icons.phone_outlined, 'اتصل بنا', () => openWhatsApp(kActivationPhoneIntl, 'مرحباً، لدي استفسار بخصوص تطبيق الدليل الشامل')),
              _tile(Icons.privacy_tip_outlined, 'سياسة الخصوصية', () => _page(context, 'سياسة الخصوصية',
                'نحن في الدليل الشامل نحترم خصوصيتك ونلتزم بحماية بياناتك الشخصية وعدم مشاركتها مع أي طرف ثالث دون إذنك.')),
            ])),
            const SizedBox(height: 16),
            TextButton(
              onPressed: () => Navigator.pushAndRemoveUntil(context, MaterialPageRoute(builder: (_) => const LandingScreen()), (r) => false),
              child: const Text('تسجيل الخروج', style: TextStyle(color: Colors.red, fontWeight: FontWeight.bold)),
            ),
          ]);
        },
      ),
    );
  }

  Widget _tile(IconData i, String t, VoidCallback onTap) =>
    ListTile(leading: Icon(i, color: kPrimary), title: Text(t, style: const TextStyle(fontWeight: FontWeight.w600)),
      trailing: const Icon(Icons.chevron_left, color: Colors.grey), onTap: onTap);

  void _page(BuildContext context, String title, String body) {
    Navigator.push(context, MaterialPageRoute(builder: (_) => Scaffold(
      appBar: AppBar(title: Text(title)),
      body: Padding(padding: const EdgeInsets.all(20), child: Text(body, style: const TextStyle(height: 1.8, fontSize: 15))),
    )));
  }
}
