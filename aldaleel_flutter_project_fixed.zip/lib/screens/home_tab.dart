import 'package:flutter/material.dart';
import '../theme.dart';
import '../data/mock_data.dart';
import 'widgets.dart';
import 'pro_screen.dart';

class HomeTab extends StatelessWidget {
  const HomeTab({super.key});

  @override
  Widget build(BuildContext context) {
    final featured = kPros.where((p) => p.premium).toList();
    return Scaffold(
      body: ListView(padding: EdgeInsets.zero, children: [
        // header
        Container(
          padding: const EdgeInsets.fromLTRB(16, 50, 16, 24),
          decoration: const BoxDecoration(
            gradient: LinearGradient(colors: [kPrimary, Color(0xFF10B981)]),
            borderRadius: BorderRadius.vertical(bottom: Radius.circular(28)),
          ),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('أهلاً بيك 👋', style: TextStyle(color: Colors.white70, fontSize: 12)),
            const Text('الدليل الشامل', style: TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.w800)),
            const SizedBox(height: 16),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
              decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(16)),
              child: Row(children: [
                Icon(Icons.search, color: Colors.grey.shade400),
                const SizedBox(width: 8),
                Text('ابحث عن حرفي أو خدمة...', style: TextStyle(color: Colors.grey.shade400)),
              ]),
            ),
          ]),
        ),
        // categories
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 20, 16, 0),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('الأقسام', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
            const SizedBox(height: 12),
            GridView.count(
              crossAxisCount: 4, shrinkWrap: true, physics: const NeverScrollableScrollPhysics(),
              mainAxisSpacing: 12, crossAxisSpacing: 12, childAspectRatio: 0.85,
              children: kCategories.take(8).map((c) => Column(children: [
                Container(
                  width: 56, height: 56,
                  decoration: BoxDecoration(color: c.color, borderRadius: BorderRadius.circular(18)),
                  child: Center(child: Text(c.icon, style: const TextStyle(fontSize: 24))),
                ),
                const SizedBox(height: 4),
                Text(c.name, style: const TextStyle(fontSize: 11), textAlign: TextAlign.center),
              ])).toList(),
            ),
          ]),
        ),
        // ad
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 16, 16, 0),
          child: Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              gradient: const LinearGradient(colors: [kPrimary, Color(0xFF14B8A6)]),
              borderRadius: BorderRadius.circular(16),
            ),
            child: const Row(children: [
              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text('عضوية الدليل 👑', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 17)),
                SizedBox(height: 4),
                Text('ظهور في البحث + نشر أعمال بـ ٦٠ج فقط', style: TextStyle(color: Colors.white70, fontSize: 12)),
              ])),
            ]),
          ),
        ),
        // featured
        const Padding(padding: EdgeInsets.fromLTRB(16, 24, 16, 12), child: Text('⭐ أعضاء مميزون', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16))),
        SizedBox(height: 150, child: ListView(scrollDirection: Axis.horizontal, padding: const EdgeInsets.symmetric(horizontal: 16),
          children: featured.map((p) => _featuredCard(context, p)).toList())),
        // latest
        const Padding(padding: EdgeInsets.fromLTRB(16, 20, 16, 12), child: Text('أحدث المنضمين', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16))),
        ...kPros.reversed.take(4).map((p) => Padding(
          padding: const EdgeInsets.fromLTRB(16, 0, 16, 10),
          child: ProCard(p: p, onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => ProScreen(pro: p)))),
        )),
        const SizedBox(height: 16),
      ]),
    );
  }

  Widget _featuredCard(BuildContext context, Pro p) {
    return GestureDetector(
      onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => ProScreen(pro: p))),
      child: Container(
        width: 150, margin: const EdgeInsets.only(left: 12),
        padding: const EdgeInsets.all(10),
        decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(16), border: Border.all(color: Colors.grey.shade200)),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          ClipRRect(borderRadius: BorderRadius.circular(12),
            child: Image.network(avatar(p.img), width: 130, height: 70, fit: BoxFit.cover,
              errorBuilder: (_, __, ___) => Container(height: 70, color: Colors.grey.shade200))),
          const SizedBox(height: 6),
          Row(children: [Flexible(child: Text(p.name, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13), overflow: TextOverflow.ellipsis)), verifiedBadge(p.verified)]),
          Text(catById(p.specialty).name, style: TextStyle(fontSize: 11, color: Colors.grey.shade500)),
          const SizedBox(height: 4),
          stars(p.rating),
        ]),
      ),
    );
  }
}
