import 'package:flutter/material.dart';
import '../theme.dart';
import '../data/mock_data.dart';
import 'register_screen.dart';
import 'home_shell.dart';
import 'admin_screen.dart';

class LandingScreen extends StatelessWidget {
  const LandingScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter,
            colors: [kPrimaryDark, Color(0xFF064E3B)]),
        ),
        child: SafeArea(
          child: Stack(children: [
            Align(
              alignment: Alignment.topLeft,
              child: TextButton(
                onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const AdminLoginScreen())),
                child: const Text('دخول الإدارة', style: TextStyle(color: Colors.white38, fontSize: 12)),
              ),
            ),
            Center(
              child: Padding(
                padding: const EdgeInsets.all(24),
                child: Column(mainAxisSize: MainAxisSize.min, children: [
                  Container(
                    width: 96, height: 96,
                    decoration: BoxDecoration(color: Colors.white24, borderRadius: BorderRadius.circular(28)),
                    child: const Center(child: Text('🛠️', style: TextStyle(fontSize: 48))),
                  ),
                  const SizedBox(height: 24),
                  const Text('الدليل الشامل', style: TextStyle(color: Colors.white, fontSize: 30, fontWeight: FontWeight.w800)),
                  const SizedBox(height: 8),
                  const Text('أكبر شبكة للحرفيين والمقاولين في مصر',
                    textAlign: TextAlign.center, style: TextStyle(color: Colors.white70, fontSize: 14)),
                  const SizedBox(height: 40),
                  SizedBox(width: double.infinity, child: ElevatedButton(
                    style: ElevatedButton.styleFrom(backgroundColor: Colors.white, foregroundColor: kPrimaryDark),
                    onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const RegisterScreen())),
                    child: const Text('تسجيل عضوية جديدة'),
                  )),
                  const SizedBox(height: 14),
                  SizedBox(width: double.infinity, child: ElevatedButton(
                    style: ElevatedButton.styleFrom(backgroundColor: Colors.white24, foregroundColor: Colors.white),
                    onPressed: () { Store.I.setRole('user'); _enter(context); },
                    child: const Text('دخول للأعضاء'),
                  )),
                  const SizedBox(height: 20),
                  TextButton(
                    onPressed: () { Store.I.setRole('guest'); _enter(context); },
                    child: const Text('الدخول كزائر',
                      style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, decoration: TextDecoration.underline)),
                  ),
                ]),
              ),
            ),
          ]),
        ),
      ),
    );
  }

  void _enter(BuildContext context) {
    Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => const HomeShell()));
  }
}
