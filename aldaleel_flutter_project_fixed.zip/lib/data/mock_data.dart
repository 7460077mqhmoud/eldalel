import 'package:flutter/material.dart';

// ===== Models =====
class Category {
  final String id, name, icon;
  final Color color;
  const Category(this.id, this.name, this.icon, this.color);
}

class Pro {
  final int id;
  final String name, specialty, gov, city, phone, whatsapp, about;
  final int exp, reviews, jobsDone, img;
  final double rating;
  final bool verified, premium;
  const Pro({
    required this.id, required this.name, required this.specialty,
    required this.gov, required this.city, required this.phone,
    required this.whatsapp, required this.about, required this.exp,
    required this.reviews, required this.jobsDone, required this.img,
    required this.rating, required this.verified, required this.premium,
  });
}

class Work {
  final int id, proId, likes;
  final String title, cat, time;
  final String? imagePath; // local file path or null (use network)
  final String seed;
  Work({required this.id, required this.proId, required this.title,
    required this.cat, required this.time, required this.likes,
    required this.seed, this.imagePath});
}

class Msg {
  final bool mine;
  final String text, time;
  Msg(this.mine, this.text, this.time);
}

// ===== Static data =====
const List<String> kGovernorates = [
  'القاهرة','الجيزة','الإسكندرية','القليوبية','الدقهلية','الشرقية','المنوفية',
  'الغربية','كفر الشيخ','البحيرة','دمياط','بورسعيد','الإسماعيلية','السويس',
  'شمال سيناء','جنوب سيناء','الفيوم','بني سويف','المنيا','أسيوط','سوهاج',
  'قنا','الأقصر','أسوان','البحر الأحمر','الوادي الجديد','مطروح',
];

const List<Category> kCategories = [
  Category('plumbing','سباكة','🔧', Color(0xFF3B82F6)),
  Category('electrical','كهرباء','💡', Color(0xFFF59E0B)),
  Category('carpentry','نجارة','🪚', Color(0xFFEA580C)),
  Category('finishing','تشطيبات','🎨', Color(0xFFF43F5E)),
  Category('plaster','محارة','🧱', Color(0xFF78716C)),
  Category('aluminum','ألوميتال','🪟', Color(0xFF0891B2)),
  Category('hvac','تكييف','❄️', Color(0xFF0EA5E9)),
  Category('tiling','سيراميك ورخام','⬜', Color(0xFF059669)),
  Category('painting','دهانات','🖌️', Color(0xFFA855F7)),
  Category('steel','حدادة','⚙️', Color(0xFF475569)),
];

Category catById(String id) =>
    kCategories.firstWhere((c) => c.id == id, orElse: () => kCategories.first);

String avatar(int seed) => 'https://i.pravatar.cc/200?img=$seed';

const List<Pro> kPros = [
  Pro(id:1,name:'أحمد عبد الله',specialty:'plumbing',gov:'القاهرة',city:'مدينة نصر',phone:'+201001234567',whatsapp:'201001234567',about:'سباك محترف متخصص في تركيب وصيانة شبكات المياه والصرف. خبرة 12 سنة.',exp:12,reviews:214,jobsDone:340,img:5,rating:4.9,verified:true,premium:true),
  Pro(id:2,name:'محمد السيد',specialty:'electrical',gov:'الجيزة',city:'المهندسين',phone:'+201112223334',whatsapp:'201112223334',about:'فني كهرباء معتمد، تأسيس وتشطيب كهرباء الشقق والفيلات.',exp:9,reviews:156,jobsDone:210,img:12,rating:4.8,verified:true,premium:true),
  Pro(id:3,name:'خالد منصور',specialty:'carpentry',gov:'القاهرة',city:'المعادي',phone:'+201223334445',whatsapp:'201223334445',about:'نجار موبيليا وديكور، تفصيل مطابخ وغرف نوم بأجود الخامات.',exp:15,reviews:98,jobsDone:175,img:33,rating:4.7,verified:true,premium:false),
  Pro(id:4,name:'مصطفى رضا',specialty:'finishing',gov:'الإسكندرية',city:'سموحة',phone:'+201334445556',whatsapp:'201334445556',about:'مقاول تشطيبات متكامل، تسليم مفتاح وإشراف هندسي.',exp:7,reviews:74,jobsDone:60,img:51,rating:4.6,verified:false,premium:false),
  Pro(id:5,name:'عمرو فتحي',specialty:'hvac',gov:'القاهرة',city:'التجمع الخامس',phone:'+201445556667',whatsapp:'201445556667',about:'متخصص تركيب وصيانة تكييفات سبليت ومركزي.',exp:10,reviews:188,jobsDone:295,img:60,rating:4.9,verified:true,premium:true),
  Pro(id:6,name:'سامح إبراهيم',specialty:'tiling',gov:'الجيزة',city:'6 أكتوبر',phone:'+201556667778',whatsapp:'201556667778',about:'تركيب سيراميك ورخام وبورسلين بأعلى دقة.',exp:11,reviews:62,jobsDone:130,img:14,rating:4.5,verified:false,premium:false),
  Pro(id:7,name:'ياسر كمال',specialty:'painting',gov:'القاهرة',city:'حلوان',phone:'+201667778889',whatsapp:'201667778889',about:'نقاش محترف، دهانات حديثة وورق حائط وديكورات جبسية.',exp:8,reviews:45,jobsDone:90,img:68,rating:4.4,verified:false,premium:false),
  Pro(id:8,name:'إسلام طارق',specialty:'aluminum',gov:'القليوبية',city:'بنها',phone:'+201778889990',whatsapp:'201778889990',about:'تفصيل وتركيب شبابيك وأبواب ألوميتال وسيكوريت.',exp:6,reviews:53,jobsDone:80,img:25,rating:4.6,verified:true,premium:false),
];

Pro proById(int id) => kPros.firstWhere((p) => p.id == id, orElse: () => kPros.first);

// ===== App state (in-memory) =====
class Store extends ChangeNotifier {
  static final Store I = Store._();
  Store._();

  String role = 'guest'; // guest | user | admin
  final Set<int> favorites = {};
  final Map<int, List<Msg>> chats = {};
  final List<Work> works = [
    Work(id:701, proId:1, title:'تشطيب حمام كامل بالسيراميك', cat:'plumbing', time:'منذ يوم', likes:34, seed:'w1'),
    Work(id:702, proId:3, title:'مطبخ خشب زان حديث', cat:'carpentry', time:'منذ يومين', likes:58, seed:'w2'),
    Work(id:703, proId:5, title:'تركيب تكييف مركزي لفيلا', cat:'hvac', time:'منذ ٣ أيام', likes:41, seed:'w3'),
    Work(id:704, proId:2, title:'لوحة توزيع كهرباء ذكية', cat:'electrical', time:'منذ أسبوع', likes:27, seed:'w4'),
  ];

  bool get isMember => role == 'user';

  void setRole(String r) { role = r; notifyListeners(); }

  void toggleFav(int id) {
    if (favorites.contains(id)) {
      favorites.remove(id);
    } else {
      favorites.add(id);
    }
    notifyListeners();
  }

  void addWork(String title, String cat, String? imagePath) {
    works.insert(0, Work(
      id: DateTime.now().millisecondsSinceEpoch,
      proId: 0, title: title, cat: cat, time: 'الآن', likes: 0,
      seed: 'u${DateTime.now().millisecondsSinceEpoch}', imagePath: imagePath,
    ));
    notifyListeners();
  }

  List<Msg> chatFor(int proId) {
    return chats.putIfAbsent(proId, () {
      final p = proById(proId);
      return [Msg(false, 'أهلاً بيك 👋 أنا ${p.name}، تحت أمرك.. محتاج أي خدمة؟', _now())];
    });
  }

  void sendMsg(int proId, String text) {
    chatFor(proId).add(Msg(true, text, _now()));
    notifyListeners();
    Future.delayed(const Duration(milliseconds: 1100), () {
      const replies = ['تمام، حاضر 👍','ممكن تبعتلي تفاصيل أكتر؟','أقدر أعدّي أعاينلك بكرة','السعر على حسب المعاينة','أنا متاح، اتصل بيا في أي وقت'];
      chats[proId]!.add(Msg(false, replies[DateTime.now().second % replies.length], _now()));
      notifyListeners();
    });
  }

  static String _now() {
    final d = DateTime.now();
    int h = d.hour; final ap = h < 12 ? 'ص' : 'م';
    h = h % 12; if (h == 0) h = 12;
    final m = d.minute.toString().padLeft(2, '0');
    return '$h:$m $ap';
  }
}
