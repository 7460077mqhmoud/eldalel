package com.example.aldaleel

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
