#!/bin/sh
# This is a generated file; do not edit or check into version control.
export "FLUTTER_ROOT=/home/user/.interactions/jFiX3nbZSvvzjT6F8K9Pr6/flutter"
export "FLUTTER_APPLICATION_PATH=/home/user/.interactions/jFiX3nbZSvvzjT6F8K9Pr6/aldaleel_flutter_project"
export "COCOAPODS_PARALLEL_CODE_SIGN=true"
export "FLUTTER_BUILD_DIR=build"
export "FLUTTER_BUILD_NAME=1.0.0"
export "FLUTTER_BUILD_NUMBER=1"
export "DART_OBFUSCATION=false"
export "TRACK_WIDGET_CREATION=true"
export "TREE_SHAKE_ICONS=false"
export "PACKAGE_CONFIG=.dart_tool/package_config.json"
