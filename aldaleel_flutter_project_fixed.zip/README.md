# الدليل الشامل — تطبيق Flutter (Android)

تطبيق دليل وسوق الحرفيين والموردين في مصر — واجهة عربية RTL، خط Cairo، Material 3.

> **ملاحظة:** ده مشروع كامل قابل للبناء فورًا. حاليًا يعمل ببيانات تجريبية داخلية (in-memory)
> عشان تجربه على طول. خطوة ربط Firebase موضّحة في آخر الملف.

---

## محتويات المشروع
```
lib/
├── main.dart                 # نقطة البداية + RTL عربي
├── theme.dart                # الثيم + خط Cairo
├── utils.dart                # اتصال / واتساب / خرائط (url_launcher)
├── data/mock_data.dart       # النماذج + البيانات + حالة التطبيق (Store)
└── screens/
    ├── landing_screen.dart   # شاشة الدخول (تسجيل / عضو / زائر / أدمن)
    ├── register_screen.dart  # تسجيل بكل محافظات مصر + الخبرة + الموقع
    ├── payment_screen.dart   # تفعيل بـ ٦٠ج + تحويل واتساب لـ 01110001986
    ├── home_shell.dart       # شريط التنقل السفلي
    ├── home_tab.dart         # الرئيسية
    ├── directory_tab.dart    # الدليل + فلترة
    ├── pro_screen.dart       # صفحة الحرفي (اتصال/واتساب/شات)
    ├── chat_screen.dart      # شات داخل التطبيق + رد تلقائي
    ├── works_tab.dart        # نشر الأعمال + رفع صورة حقيقية (image_picker)
    ├── menu_tab.dart         # حسابي + من نحن + اتصل بنا + الخصوصية
    └── admin_screen.dart     # لوحة الأدمن (قبول/رفض/تفعيل)
.github/workflows/build-apk.yml  # بناء APK أوتوماتيك في السحابة
```

---

## 🟢 الطريقة الأسهل لإنتاج APK (بدون تنصيب أي شيء)

1. ارفع المشروع على مستودع **GitHub** جديد (Push).
2. اذهب لتبويب **Actions** في المستودع → شغّل workflow باسم **Build Android APK** (أو يشتغل تلقائيًا بعد الرفع).
3. بعد ما يخلص (٥-٨ دقائق)، نزّل ملف **aldaleel-apk** من قسم Artifacts.
4. انقل الـ `app-release.apk` للموبايل وثبّته (فعّل "تثبيت من مصادر غير معروفة").

> الـ workflow بيعمل تلقائيًا: توليد مجلدات أندرويد، إضافة صلاحيات الاتصال/الواتساب، البناء، ورفع الـ APK.

---

## 💻 البناء محليًا (لو عندك Flutter)

```bash
flutter create --platforms=android --project-name aldaleel .   # توليد مجلدات أندرويد
flutter pub get
flutter run                # تشغيل على محاكي/جهاز
flutter build apk --release  # إنتاج APK نهائي
```
الناتج: `build/app/outputs/flutter-apk/app-release.apk`

> لو ظهرت مشكلة في زر الاتصال/واتساب على أندرويد 11+، أضف وسم `<queries>` في
> `android/app/src/main/AndroidManifest.xml` (الـ workflow بيعمل ده تلقائيًا).

---

## 🔥 خطوة ربط Firebase (الإنتاج الحقيقي)

عشان يبقى تطبيق حقيقي متعدد المستخدمين (تسجيل، بيانات حية، إشعارات):
1. `dart pub global activate flutterfire_cli` ثم `flutterfire configure`.
2. أضف الحزم: `firebase_core, firebase_auth, cloud_firestore, firebase_storage, firebase_messaging`.
3. استبدل `Store` و `mock_data.dart` بمستودعات تقرأ/تكتب من Firestore.
4. طبّق قواعد الأمان من حزمة المعمارية (`firestore.rules`).

بنية قاعدة البيانات، قواعد الأمان، والـ Cloud Functions كلها جاهزة في ملف
**aldaleel_architecture.zip** اللي اتسلّم قبل كده.

---

## بيانات الدخول التجريبية
- **الأدمن:** البريد `admin@aldaleel.com` — كلمة المرور `123456`
- **عضو / زائر:** من شاشة الدخول مباشرة
- **رقم التفعيل:** 01110001986 — رسوم الاشتراك ٦٠ ج
